"""
Central configuration for FireSentry.

All secrets and machine-specific paths are loaded from environment
variables (via a local .env file) instead of being hardcoded, so the
project is safe to publish and easy to run on any machine.

Copy `.env.example` to `.env` and fill in your own values before running
anything that needs Twilio alerts.
"""

import os
from pathlib import Path

from dotenv import load_dotenv

# Load variables from a .env file in the project root, if present.
load_dotenv()

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
BASE_DIR = Path(__file__).resolve().parent

MODEL_PATH = Path(os.getenv("MODEL_PATH", BASE_DIR / "models" / "fire_detection_model1.h5"))
ALARM_PATH = Path(os.getenv("ALARM_PATH", BASE_DIR / "assets" / "Alarm.mp3"))

# Dataset paths (only needed for training / evaluation scripts)
DATASET_PATH = Path(os.getenv("DATASET_PATH", BASE_DIR / "data" / "D-Fire"))
TRAIN_IMAGES_DIR = DATASET_PATH / "train" / "images"
TRAIN_LABELS_DIR = DATASET_PATH / "train" / "labels"
TEST_IMAGES_DIR = DATASET_PATH / "test" / "images"
TEST_LABELS_DIR = DATASET_PATH / "test" / "labels"

# ---------------------------------------------------------------------------
# Twilio (SMS / WhatsApp alerts) — leave blank in .env to disable alerts
# ---------------------------------------------------------------------------
TWILIO_ACCOUNT_SID = os.getenv("TWILIO_ACCOUNT_SID", "")
TWILIO_AUTH_TOKEN = os.getenv("TWILIO_AUTH_TOKEN", "")
TWILIO_SMS_NUMBER = os.getenv("TWILIO_SMS_NUMBER", "")
TWILIO_WHATSAPP_NUMBER = os.getenv("TWILIO_WHATSAPP_NUMBER", "")
RECIPIENT_PHONE_NUMBER = os.getenv("RECIPIENT_PHONE_NUMBER", "")
RECIPIENT_WHATSAPP_NUMBER = os.getenv("RECIPIENT_WHATSAPP_NUMBER", "")

ALERTS_ENABLED = bool(TWILIO_ACCOUNT_SID and TWILIO_AUTH_TOKEN)

# ---------------------------------------------------------------------------
# Detection tuning
# ---------------------------------------------------------------------------
IMAGE_SIZE = (224, 224)
PROB_THRESHOLD = float(os.getenv("PROB_THRESHOLD", 0.75))   # model probability threshold
AVG_WINDOW = int(os.getenv("AVG_WINDOW", 5))                # moving-average window size
MIN_CONSECUTIVE = int(os.getenv("MIN_CONSECUTIVE", 3))      # consecutive confirmed frames needed
COLOR_MASK_FRAC = float(os.getenv("COLOR_MASK_FRAC", 0.01))  # min fraction of fire-colored pixels
