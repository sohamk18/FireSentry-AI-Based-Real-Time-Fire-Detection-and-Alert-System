import os

import cv2
import numpy as np
import tensorflow as tf


class YOLODataset:
    """Loads a YOLO-format object detection dataset and converts it into
    binary fire / no-fire classification labels for the CNN classifier.
    """

    def __init__(self, image_dir, label_dir, image_size=(224, 224)):
        self.image_dir = image_dir
        self.label_dir = label_dir
        self.image_size = image_size
        self.image_paths = sorted(
            os.path.join(image_dir, f) for f in os.listdir(image_dir) if f.endswith(".jpg")
        )
        self.label_paths = sorted(
            os.path.join(label_dir, f) for f in os.listdir(label_dir) if f.endswith(".txt")
        )

    def load_image_label(self, image_path, label_path):
        image = cv2.imread(image_path)
        image = cv2.resize(image, self.image_size)
        image = image / 255.0  # Normalize

        # YOLO label format: class_id x_center y_center width height
        label = 0  # Default: no fire
        if os.path.exists(label_path):
            with open(label_path, "r") as f:
                for line in f:
                    class_id, _, _, _, _ = map(float, line.split())
                    if int(class_id) == 1:  # class '1' == fire
                        label = 1
                        break

        return image, label

    def data_generator(self):
        for img_path, lbl_path in zip(self.image_paths, self.label_paths):
            yield self.load_image_label(img_path, lbl_path)

    def get_tf_dataset(self, batch_size=32):
        dataset = tf.data.Dataset.from_generator(
            self.data_generator,
            output_signature=(
                tf.TensorSpec(shape=(*self.image_size, 3), dtype=tf.float32),
                tf.TensorSpec(shape=(), dtype=tf.int32),
            ),
        )
        return dataset.batch(batch_size).prefetch(tf.data.AUTOTUNE)
