"""
FireSentry — real-time fire detection from a live camera feed.

Pipeline:
    1. Capture frames from a webcam / surveillance camera (OpenCV)
    2. Run each frame through a MobileNetV2-based CNN classifier
    3. Smooth predictions with a moving average + confirm with an
       HSV color-mask heuristic to reduce false positives
    4. On a confirmed detection: play a local alarm and (optionally)
       send SMS / WhatsApp alerts via Twilio with the current location
"""

import threading
from collections import deque

import cv2
import numpy as np
import requests
from geopy.geocoders import Nominatim
from playsound import playsound
from tensorflow.keras.applications import MobileNetV2
from tensorflow.keras.layers import Dense, GlobalAveragePooling2D
from tensorflow.keras.models import Model

import config

if config.ALERTS_ENABLED:
    from twilio.rest import Client
    twilio_client = Client(config.TWILIO_ACCOUNT_SID, config.TWILIO_AUTH_TOKEN)
else:
    twilio_client = None
    print("ℹ️  Twilio credentials not set — SMS/WhatsApp alerts are disabled. "
          "See .env.example to enable them.")


# ---------------------------------------------------------------------------
# Model loading
# ---------------------------------------------------------------------------
def load_fire_model():
    """Recreate the MobileNetV2-based architecture and load saved weights.

    The saved .h5 file only contains the custom classification head, so we
    rebuild the base MobileNetV2 (ImageNet weights) and load the head
    weights by name on top of it.
    """
    base_model = MobileNetV2(weights="imagenet", include_top=False, input_shape=(*config.IMAGE_SIZE, 3))
    x = base_model.output
    x = GlobalAveragePooling2D()(x)
    x = Dense(128, activation="relu", name="dense_128")(x)
    x = Dense(1, activation="sigmoid", name="predictions")(x)  # Fire vs. No Fire

    model = Model(inputs=base_model.input, outputs=x)
    for layer in base_model.layers:
        layer.trainable = False

    model.load_weights(str(config.MODEL_PATH), by_name=True)
    print("✅ Model architecture created and weights loaded successfully!")
    return model


model = load_fire_model()

# Moving-average window of recent fire probabilities
prob_window = deque(maxlen=config.AVG_WINDOW)
fire_detected_count = 0


# ---------------------------------------------------------------------------
# Alerts
# ---------------------------------------------------------------------------
def get_location() -> str:
    """Best-effort IP-based geolocation, for context in alert messages."""
    try:
        response = requests.get("http://ip-api.com/json/", timeout=5)
        data = response.json()
        if data.get("status") == "fail":
            return "🌍 Location: Not Found"

        latitude, longitude = data["lat"], data["lon"]
        geolocator = Nominatim(user_agent="firesentry")
        location = geolocator.reverse(f"{latitude}, {longitude}")
        return f"📍 Location: {location.address} (Lat: {latitude}, Lon: {longitude})"
    except Exception as e:
        return f"❌ Error fetching location: {e}"


def send_sms_alert():
    if not twilio_client:
        return
    location_info = get_location()
    message = twilio_client.messages.create(
        body=f"🔥 ALERT: Fire detected!\n{location_info}",
        from_=config.TWILIO_SMS_NUMBER,
        to=config.RECIPIENT_PHONE_NUMBER,
    )
    print(f"✅ SMS Sent: {message.sid}")


def send_whatsapp_alert():
    if not twilio_client:
        return
    location_info = get_location()
    message = twilio_client.messages.create(
        body=f"🔥 ALERT: Fire detected!\n{location_info}",
        from_="whatsapp:" + config.TWILIO_WHATSAPP_NUMBER,
        to="whatsapp:" + config.RECIPIENT_WHATSAPP_NUMBER,
    )
    print(f"✅ WhatsApp Alert Sent: {message.sid}")


def play_alarm():
    print("🔊 Playing Alarm!")
    if not config.ALARM_PATH.exists():
        print(f"⚠️ Alarm file not found: {config.ALARM_PATH}. Skipping sound.")
        return
    try:
        playsound(str(config.ALARM_PATH))
    except Exception as e:
        print(f"⚠️ Failed to play alarm: {e}")


def trigger_alerts():
    """Run the alarm sound and messaging alerts in background threads."""
    threading.Thread(target=play_alarm, daemon=True).start()
    if twilio_client:
        threading.Thread(target=send_sms_alert, daemon=True).start()
        threading.Thread(target=send_whatsapp_alert, daemon=True).start()


# ---------------------------------------------------------------------------
# Detection
# ---------------------------------------------------------------------------
def detect_fire(frame, debug: bool = False):
    """Classify a single frame as fire / no-fire.

    Combines a CNN probability (smoothed with a moving average) with an
    HSV color-mask heuristic, and requires several consecutive confirmed
    frames before reporting a positive detection — this suppresses one-off
    false positives from glare, bright lights, etc.

    Returns:
        (label, color, is_fire) normally, or
        (label, color, is_fire, avg_prob, mask_frac) if debug=True
    """
    global fire_detected_count

    resized_frame = cv2.resize(frame, config.IMAGE_SIZE)
    img_array = np.expand_dims(np.array(resized_frame) / 255.0, axis=0)

    prob = float(model.predict(img_array, verbose=0)[0][0])
    prob_window.append(prob)
    avg_prob = sum(prob_window) / len(prob_window)

    # HSV color-mask heuristic (red/orange/yellow fire-like colors)
    hsv = cv2.cvtColor(resized_frame, cv2.COLOR_BGR2HSV)
    lower1, upper1 = np.array([0, 100, 100]), np.array([35, 255, 255])
    lower2, upper2 = np.array([160, 100, 100]), np.array([179, 255, 255])
    mask = cv2.bitwise_or(cv2.inRange(hsv, lower1, upper1), cv2.inRange(hsv, lower2, upper2))
    mask_frac = float(np.count_nonzero(mask) / mask.size)

    is_model_fire = avg_prob >= config.PROB_THRESHOLD
    is_color_fire = mask_frac >= config.COLOR_MASK_FRAC
    is_fire = is_model_fire and is_color_fire

    fire_detected_count = fire_detected_count + 1 if is_fire else 0
    confirmed = fire_detected_count >= config.MIN_CONSECUTIVE

    label = "Fire Detected!" if confirmed else f"No Fire (p={avg_prob:.2f}, m={mask_frac:.3f})"
    color = (0, 0, 255) if confirmed else (0, 255, 0)

    if debug:
        return label, color, confirmed, avg_prob, mask_frac
    return label, color, confirmed


# ---------------------------------------------------------------------------
# Main loop
# ---------------------------------------------------------------------------
def main():
    cap = cv2.VideoCapture(0)
    fire_already_alerted = False

    if not cap.isOpened():
        print("❌ Could not open camera. Check your camera index / permissions.")
        return

    print("🎥 Fire detection running — press 'q' to quit.")
    while True:
        ret, frame = cap.read()
        if not ret:
            break

        label, color, is_fire = detect_fire(frame)
        cv2.putText(frame, label, (20, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, color, 2)
        cv2.imshow("FireSentry - Fire Detection System", frame)

        if is_fire and not fire_already_alerted:
            fire_already_alerted = True
            print("🔥 ALERT! Fire Detected!")
            trigger_alerts()
        elif not is_fire:
            fire_already_alerted = False

        if cv2.waitKey(1) & 0xFF == ord("q"):
            break

    cap.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
