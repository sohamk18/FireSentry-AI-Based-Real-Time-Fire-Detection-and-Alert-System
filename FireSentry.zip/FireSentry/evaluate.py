"""
Evaluate the trained FireSentry model's accuracy on the D-Fire test split.
"""

from tensorflow.keras.models import load_model

import config
from yolo_data_loader import YOLODataset


def main():
    model = load_model(str(config.MODEL_PATH))

    test_dataset = YOLODataset(str(config.TEST_IMAGES_DIR), str(config.TEST_LABELS_DIR), image_size=config.IMAGE_SIZE)
    test_generator = test_dataset.get_tf_dataset(batch_size=32)

    loss, accuracy = model.evaluate(test_generator)
    print(f"🔥 Fire Detection Model Accuracy: {accuracy * 100:.2f}%")


if __name__ == "__main__":
    main()
