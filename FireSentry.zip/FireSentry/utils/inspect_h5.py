"""
Inspect the raw structure of the saved .h5 weights file.

Usage:
    python utils/inspect_h5.py
"""

import sys
from pathlib import Path

sys.path.append(str(Path(__file__).resolve().parent.parent))

import h5py

import config


def main():
    try:
        with h5py.File(str(config.MODEL_PATH), "r") as f:
            print("HDF5 top-level keys:")
            for k in f.keys():
                print("  ", k)

            print("\nFull file structure (first 200 items):")
            for count, (name, obj) in enumerate(f.items()):
                if count > 200:
                    break
                print(name, type(obj))
    except Exception:
        import traceback
        print("Error reading HDF5:")
        traceback.print_exc()


if __name__ == "__main__":
    main()
