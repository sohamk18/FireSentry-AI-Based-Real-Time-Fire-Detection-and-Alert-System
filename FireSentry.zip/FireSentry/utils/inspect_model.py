"""
Inspect the saved model's architecture, layers, and input/output shapes.
Useful when debugging weight-loading issues.

Usage:
    python utils/inspect_model.py
"""

import sys
from pathlib import Path

sys.path.append(str(Path(__file__).resolve().parent.parent))

from tensorflow.keras.models import load_model

import config


def main():
    try:
        model = load_model(str(config.MODEL_PATH))
        print("Loaded model successfully\n")
        model.summary()

        print("\nModel inputs:")
        for inp in model.inputs:
            print(f"  {inp.name} shape={inp.shape}")

        print("\nModel outputs:")
        for out in model.outputs:
            print(f"  {out.name} shape={out.shape}")

        print("\nDense layers:")
        for layer in model.layers:
            if layer.__class__.__name__ == "Dense":
                print(f"  {layer.name}: units={layer.units}")

    except Exception:
        import traceback
        print("Error loading model:")
        traceback.print_exc()
        print("\nIf loading fails, the model may have multiple inputs or custom objects.")


if __name__ == "__main__":
    main()
