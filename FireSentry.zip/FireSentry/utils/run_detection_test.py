"""
Run fire detection on a single sample image, for quick debugging.

Usage:
    python utils/run_detection_test.py path/to/image.jpg
"""

import sys
from pathlib import Path

sys.path.append(str(Path(__file__).resolve().parent.parent))

import cv2

import fire_detection


def main():
    if len(sys.argv) < 2:
        print("Usage: python utils/run_detection_test.py <path_to_image>")
        return

    sample = Path(sys.argv[1])
    if not sample.exists():
        print("Sample image not found:", sample)
        return

    frame = cv2.imread(str(sample))
    if frame is None:
        print("Failed to read image")
        return

    result = fire_detection.detect_fire(frame, debug=True)
    print("detect_fire result:", result)


if __name__ == "__main__":
    main()
