# 🔥 FireSentry — AI-Powered Surveillance Camera Fire Detection

FireSentry is a real-time fire detection system that turns a standard webcam or surveillance camera into an intelligent early-warning tool. It combines a fine-tuned **MobileNetV2 CNN** with a lightweight **HSV color-mask heuristic** to detect fire in live video, then automatically alerts people via **SMS and WhatsApp** (Twilio) with the detected location, plus a local audio alarm.

Unlike simple single-frame classifiers, FireSentry reduces false positives by requiring:
- **Model confidence** above a probability threshold, smoothed over a rolling window of recent frames
- **Color-based confirmation** — a minimum fraction of fire-colored (red/orange/yellow) pixels via HSV masking
- **Temporal consistency** — several consecutive confirmed frames before triggering an alert

## How it works

1. Captures live video via OpenCV
2. Preprocesses each frame (resize to 224×224, normalize) for the CNN
3. Runs inference through a MobileNetV2-based binary classifier (fire / no fire)
4. Applies a moving-average probability filter + HSV color-mask check to suppress false alarms
5. On a confirmed detection:
   - 🔊 Plays a local audio alarm
   - 📍 Fetches approximate location via IP geolocation + reverse geocoding
   - 📩 Sends SMS and WhatsApp alerts through the Twilio API

## Demo

| No Fire | Fire Detected |
|---|---|
| Green label, camera feed monitoring normally | Red "Fire Detected!" label + alert triggered |

## Project structure

```
FireSentry/
├── fire_detection.py       # Main real-time detection loop + alerts
├── train.py                 # Train the CNN on the D-Fire dataset
├── evaluate.py               # Evaluate model accuracy on the test set
├── yolo_data_loader.py       # Converts YOLO-format labels to binary fire labels
├── config.py                 # Central config — loads paths & secrets from .env
├── utils/
│   ├── inspect_model.py      # Inspect model architecture/layers
│   ├── inspect_h5.py         # Inspect raw .h5 weights file structure
│   └── run_detection_test.py # Run detection on a single sample image
├── models/
│   └── fire_detection_model1.h5   # Trained model weights
├── assets/
│   └── Alarm.mp3              # Alarm sound played on detection
├── requirements.txt
├── .env.example
└── .gitignore
```

## Setup

### 1. Clone and install dependencies

```bash
git clone https://github.com/<your-username>/FireSentry.git
cd FireSentry
python -m venv venv
source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Configure environment variables

```bash
cp .env.example .env
```

Edit `.env` and fill in your own **Twilio** credentials if you want SMS/WhatsApp alerts. Leave them blank to run detection-only (alarm sound still works).

> ⚠️ **Never commit your `.env` file.** It's already excluded via `.gitignore`.

### 3. Run real-time detection

```bash
python fire_detection.py
```

Press `q` to quit the camera window.

## Training your own model

FireSentry's classifier was trained via transfer learning on **MobileNetV2** (ImageNet weights, frozen base) using the **[D-Fire dataset](https://github.com/gaiasd/DFireDataset)** (YOLO-format annotations, converted to binary fire/no-fire labels).

1. Download the D-Fire dataset and place it under `data/D-Fire/` (or set `DATASET_PATH` in `.env`), matching this structure:
   ```
   data/D-Fire/
   ├── train/
   │   ├── images/*.jpg
   │   └── labels/*.txt
   └── test/
       ├── images/*.jpg
       └── labels/*.txt
   ```
2. Run training:
   ```bash
   python train.py
   ```
3. Evaluate accuracy on the held-out test set:
   ```bash
   python evaluate.py
   ```

## Tech stack

- **Python**, **TensorFlow / Keras** (MobileNetV2 CNN)
- **OpenCV** — video capture, frame processing, HSV color masking
- **NumPy**
- **Twilio API** — SMS & WhatsApp alerts
- **Geopy** — reverse geocoding for location in alerts
- **playsound** — local audio alarm
- **python-dotenv** — environment-based configuration

## Advantages

- **Early detection** — flags fire within seconds, without waiting for smoke/heat to reach a physical sensor
- **Leverages existing infrastructure** — works with any standard webcam or IP camera
- **Reduced false alarms** — combined CNN + color-mask + temporal-confirmation approach filters out glare, bright lights, and momentary noise
- **Multi-channel alerts** — audio, SMS, and WhatsApp notifications with location context
- **Scalable** — deployable in homes, offices, warehouses, and industrial or outdoor settings

## Known limitations

- Lighting conditions (night-time footage, glare) and environmental factors (fog, steam) can still affect accuracy
- Model performance depends on the diversity/quality of training data
- Currently single-camera / single-process; not yet built for distributed multi-camera deployments

## Contributing

Issues and pull requests are welcome. If you improve detection accuracy, add multi-camera support, or containerize the app, please open a PR.

## License

This project is licensed under the [MIT License](LICENSE).

## Acknowledgements

Built as a mini-project by Purva Pawar, Devanshu Manchekar, Samarth Lokhande, and Soham Kalolikar, Department of Computer Science & Engineering (AI & ML), A. P. Shah Institute of Technology, University of Mumbai, under the guidance of Prof. Vijaya Bharathi Jagan. Trained on the [D-Fire dataset](https://github.com/gaiasd/DFireDataset).
