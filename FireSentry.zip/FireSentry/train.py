"""
Train the FireSentry fire/no-fire classifier on the D-Fire dataset.

Uses transfer learning on MobileNetV2 (frozen ImageNet base + a small
trainable classification head). Expects the dataset in YOLO format:

    data/D-Fire/
        train/
            images/*.jpg
            labels/*.txt
        test/
            images/*.jpg
            labels/*.txt

Download the D-Fire dataset and set DATASET_PATH in your .env file if it
lives somewhere other than ./data/D-Fire.
"""

import tensorflow as tf

import config
from yolo_data_loader import YOLODataset

IMAGE_SIZE = config.IMAGE_SIZE
BATCH_SIZE = 32
EPOCHS = 10


def check_dataset():
    missing = [p for p in (config.TRAIN_IMAGES_DIR, config.TEST_IMAGES_DIR) if not p.exists()]
    if missing:
        raise FileNotFoundError(
            f"Dataset folder(s) not found: {missing}. "
            f"Set DATASET_PATH in your .env file to point at the D-Fire dataset."
        )
    print("✅ Dataset check complete.")


def build_model():
    base_model = tf.keras.applications.MobileNetV2(
        input_shape=(*IMAGE_SIZE, 3), include_top=False, weights="imagenet"
    )
    base_model.trainable = False

    model = tf.keras.Sequential([
        base_model,
        tf.keras.layers.GlobalAveragePooling2D(),
        tf.keras.layers.Dense(128, activation="relu"),
        tf.keras.layers.Dropout(0.3),
        tf.keras.layers.Dense(1, activation="sigmoid"),
    ])
    model.compile(optimizer="adam", loss="binary_crossentropy", metrics=["accuracy"])
    return model


def main():
    check_dataset()

    train_dataset = YOLODataset(str(config.TRAIN_IMAGES_DIR), str(config.TRAIN_LABELS_DIR), image_size=IMAGE_SIZE)
    val_dataset = YOLODataset(str(config.TEST_IMAGES_DIR), str(config.TEST_LABELS_DIR), image_size=IMAGE_SIZE)

    train_generator = train_dataset.get_tf_dataset(batch_size=BATCH_SIZE)
    val_generator = val_dataset.get_tf_dataset(batch_size=BATCH_SIZE)

    model = build_model()
    model.fit(
        train_generator.repeat(),
        validation_data=val_generator,
        epochs=EPOCHS,
        steps_per_epoch=max(1, len(train_dataset.image_paths) // BATCH_SIZE),
        validation_steps=max(1, len(val_dataset.image_paths) // BATCH_SIZE),
    )

    output_path = config.BASE_DIR / "models" / "fire_detection_model1.h5"
    model.save(str(output_path))
    print(f"🔥 Model saved to {output_path}")


if __name__ == "__main__":
    main()
